package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Trajectory simulation chuẩn Minecraft:
 * - Spawn tại eye + offset 0.5 block phía trước
 * - Gravity 0.05/tick, drag 0.99/tick
 * - Khớp với BowItem.onStoppedUsing()
 */
public final class BowTrajectoryUtil {
    private BowTrajectoryUtil() {}

    public static BlockPos predictLanding(ClientPlayerEntity player, int useTimeLeft) {
        World world = player.getWorld();
        float pull = BowItem.getPullProgress(useTimeLeft);
        if (pull < 0.1f) return null;

        float speed = pull * 3.0f;

        // Direction từ yaw/pitch
        float yawRad   = (float) Math.toRadians(player.getYaw());
        float pitchRad = (float) Math.toRadians(player.getPitch());
        double vx = -Math.sin(yawRad) * Math.cos(pitchRad);
        double vy = -Math.sin(pitchRad);
        double vz =  Math.cos(yawRad) * Math.cos(pitchRad);
        double len = Math.sqrt(vx*vx + vy*vy + vz*vz);
        if (len == 0) return null;
        vx = vx/len * speed;
        vy = vy/len * speed;
        vz = vz/len * speed;

        // Spawn: eye + 0.5 block theo hướng nhìn (đúng như Minecraft)
        Vec3d dir = new Vec3d(vx/speed, vy/speed, vz/speed);
        Vec3d eye = player.getEyePos();
        double x = eye.x + dir.x * 0.5;
        double y = eye.y + dir.y * 0.5;
        double z = eye.z + dir.z * 0.5;

        for (int i = 0; i < 120; i++) {
            vy -= 0.05;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;

            BlockPos cur   = BlockPos.ofFloored(x, y, z);
            BlockPos below = cur.down();

            if (!world.getBlockState(cur).isAir()) {
                // Tên chạm block — vị trí trước đó
                BlockPos prev = BlockPos.ofFloored(x - vx, y - vy, z - vz);
                if (world.getBlockState(prev).isAir()) return prev;
                return null;
            }
            if (!world.getBlockState(below).isAir()) {
                if (world.getBlockState(cur).isAir()) return cur;
            }
        }
        return null;
    }

    public static boolean isHoldingBow(ClientPlayerEntity player) {
        return player.getMainHandStack().getItem() instanceof BowItem ||
               player.getOffHandStack().getItem() instanceof BowItem;
    }
}
